PredDrugInducedLiverInjury 0.0.1
======================
  - A skeleton package that can be used to develop studies to train and internally validate patient-level prediction models
