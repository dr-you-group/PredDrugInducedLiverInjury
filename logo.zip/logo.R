.libPaths("F:/R/library")
library(DatabaseConnector)
connectionDetails <- DatabaseConnector::createConnectionDetails(dbms = "postgresql",
                                                                server = "192.168.132.12/cdm_yuhs53",
                                                                user = "postgres",
                                                                password = "PGpostgres20",
                                                                port = "5432",
                                                                pathToDriver  = "F:/jdbc")
connection <- connect(connectionDetails)
df <- DatabaseConnector::querySql(connection, "select * from pg_stat_activity")

View(df)
